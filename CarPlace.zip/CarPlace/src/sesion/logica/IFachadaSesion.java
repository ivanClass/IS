package sesion.logica;

public interface IFachadaSesion {

	public boolean login(String nick, String pass);
	
	public void logOut(String nick);
	
	
	
}
